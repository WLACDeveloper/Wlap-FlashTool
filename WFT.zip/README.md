# WALMFast

![изображение](https://github.com/user-attachments/assets/29772e85-5d0d-4039-b2ab-36553e911918)


## WALMFAST - WALM Fastboot - making it easier to flash devices via fastboot
