model = 'Redmi 9A'
image = 'dandelion.jpg'
official_firmwares_forum_forpda = 'https://4pda.to/forum/index.php?showtopic=1005664'
nonofficial_firmwares_forum_forpda = 'https://4pda.to/forum/index.php?showtopic=1049197'
twrp = 'https://4pda.to/forum/index.php?showtopic=1005664&st=18200#entry123178076'
orangefox = 'https://4pda.to/forum/index.php?showtopic=1005664&st=20640#entry128163562'
pbrp = 'https://4pda.to/forum/index.php?showtopic=1012866&view=findpost&p=104474033'
nonuniversalboot = True
partitions = ['super.img',
              'recovery.img',
              'boot.img',
              'vbmeta.img',
              'userdata.img']
