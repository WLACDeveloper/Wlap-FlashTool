model = 'Redmi 13C'
image = 'gale.jpg'
official_firmwares_forum_forpda = 'https://4pda.to/forum/index.php?showtopic=1080405'
nonofficial_firmwares_forum_forpda = 'https://4pda.to/forum/index.php?showtopic=1094689'
twrp = 'https://4pda.to/forum/index.php?showtopic=1094689&st=60#entry132486211'
orangefox = 'https://4pda.to/forum/index.php?showtopic=1080405&view=findpost&p=131192173'
pbrp = 'https://4pda.to/forum/index.php?showtopic=1080405&st=440#entry131193918'
nonuniversalboot = False
partitions = ['super.img',
              'boot.img',
              'vbmeta.img',
              'userdata.img']

