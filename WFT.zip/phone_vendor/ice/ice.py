model = 'Redmi A1+'
image = 'ice.png'
official_firmwares_forum_forpda = 'https://4pda.to/forum/index.php?showtopic=1057795'
nonofficial_firmwares_forum_forpda = 'https://4pda.to/forum/index.php?showtopic=1057795'
twrp = 'https://4pda.to/forum/index.php?showtopic=1057795&st=540#entry124031366'
nonuniversalboot = False
partitions = ['super.img',
              'boot.img',
              'vbmeta.img',
              'userdata.img']

