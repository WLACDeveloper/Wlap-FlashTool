pip install wget customtkinter pygame Pillow show-in-file-manager crossfiledialog xdialog --break-system-packages
pip3 install wget customtkinter pygame Pillow show-in-file-manager crossfiledialog xdialog --break-system-packages
python main.py
python3 main.py